#ifndef HW3_IMPL_H
#define HW3_IMPL_H

#include <algorithm>
#include <cstdlib>
#include <vector>

#include "hw3.h"

template <typename T>
BST<T>::BST() {
  // COMPLETE HERE
}

template <typename T>
BST<T>::~BST() {
  // COMPLETE HERE
}

template <typename T>
void BST<T>::insert(T const& value) {
  // COMPLETE HERE
}

template <typename T>
bool BST<T>::search(T const& value) const {
  // COMPLETE HERE
}

template <typename T>
void BST<T>::remove(T const& value) {
  // COMPLETE HERE
}

template <typename T>
size_t BST<T>::size() const {
  // COMPLETE HERE
  return 0;
}

template <typename T>
T BST<T>::findMin() const {
  // COMPLETE HERE
}

template <typename T>
T BST<T>::findMax() const {
  // COMPLETE HERE
}

template <typename T>
bool BST<T>::isEmpty() const {
  // COMPLETE HERE
}

template <typename T>
void BST<T>::clear() {
  // COMPLETE HERE
}


#endif
