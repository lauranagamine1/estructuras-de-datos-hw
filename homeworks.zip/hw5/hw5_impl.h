#ifndef HW5_IMPL_H
#define HW5_IMPL_H

#include <string>
#include <vector>

#include "hw5.h"

void add_edge(std::vector<std::vector<int>>& graph, int from, int to) {
  // COMPLETE AQUI
}

int n_vertices(std::vector<std::vector<int>> const& graph) {
  // COMPLETE AQUI
  return 0;
}

int n_edges(std::vector<std::vector<int>> const& graph) {
  // COMPLETE AQUI
  return 0;
}

std::vector<int> BFS(std::vector<std::vector<int>> const& graph, int from) {
  // COMPLETE AQUI
  std::vector<int> ret;
  return ret;
}

std::vector<int> DFS(std::vector<std::vector<int>> const& graph, int from) {
  // COMPLETE AQUI
  std::vector<int> ret;
  return ret;
}

std::vector<std::vector<int>> connected_components(
  std::vector<std::vector<int>> const& graph) {
  // COMPLETE AQUI
  std::vector<std::vector<int>> ret;
  return ret;

}

int n_connected_components(std::vector<std::vector<int>> const& graph) {
  // COMPLETE AQUI
  return 0;
}

#endif
